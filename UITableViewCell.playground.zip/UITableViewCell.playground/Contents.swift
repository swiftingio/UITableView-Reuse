import UIKit
import PlaygroundSupport

class MyCell: UITableViewCell {
    override func prepareForReuse() {
        super.prepareForReuse()
        backgroundColor = .red
    }
}

public extension UITableViewCell {
    public static var identifier: String { return String(describing: self) }
}

public extension UITableView {
    public func register(_ cell: UITableViewCell.Type) {
        register(cell, forCellReuseIdentifier: cell.identifier)
    }
    
    public func dequeueReusableCell<CellClass: UITableViewCell>(of class: CellClass.Type,
                                    for indexPath: IndexPath,
                                    configure: ((CellClass) -> Void) = { _ in }) -> UITableViewCell {
        
        let cell = dequeueReusableCell(withIdentifier: CellClass.identifier,
                                       for: indexPath)
        
        if let typedCell = cell as? CellClass {
            configure(typedCell)
        }
        
        return cell
    }
}

class DataSource: NSObject, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        return tableView.dequeueReusableCell(of: MyCell.self, for: indexPath) { cell in
            cell.textLabel?.text = indexPath.description
        }
    }
}

let tableView = UITableView()
let dataSource = DataSource()

tableView.frame = CGRect(x: 0, y: 0, width: 320, height: 480)
tableView.dataSource = dataSource
tableView.register(MyCell.self)
tableView.reloadData()

PlaygroundSupport.PlaygroundPage.current.liveView = tableView
